import { Component } from '@angular/core';
import { catchError, concatMap, delay, Observable, of, retryWhen, Subject, throwError } from 'rxjs';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-demo',
  imports: [],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {

  constructor(private productService:ProductService){

  }

  invoke(){
  
      this.productService.getProducts().pipe(
        retryWhen(errors =>
          errors.pipe(
            concatMap((err, i) => i < 10 ? of(err).pipe(delay(2000)) : throwError(() => err))
          )
        ),
      
        catchError(error => {
          console.error('Error occurred:', error);
          return of({
            message:" something went wrong! please try again after sometime"
          }); // fallback value
        })
      
      ).subscribe(
        {
          next: data => console.log(data), 
          error: error => console.log("error occured"),
          complete: () => console.log("operation completed")
        }
      )
    
  }

  

}
