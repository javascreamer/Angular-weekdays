import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { SingletonComponent } from './singleton/singleton.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RouterLink,SingletonComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'spa';
}
