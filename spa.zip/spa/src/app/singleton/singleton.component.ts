import { Component } from '@angular/core';
import { CounterService } from '../counter.service';

@Component({
  selector: 'app-singleton',
  imports: [],
  templateUrl: './singleton.component.html',
  styleUrl: './singleton.component.css',
})
export class SingletonComponent {

  counterValue:number = 0;

  constructor(private counterService:CounterService){

     this.counterValue = this.counterService.getCounter();

  }

  incrementCounter(){
      this.counterService.increment();
      this.counterValue = this.counterService.getCounter();
  }


}
