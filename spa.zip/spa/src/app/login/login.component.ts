import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { usernameExistsValidator, UsernameValidator } from '../User.Validator';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private router:Router){

    

  } 

  form = new FormGroup(
    {
        username: new FormControl('',[
          Validators.required,
           Validators.minLength(5), 
           Validators.maxLength(10),
           UsernameValidator.shouldNotHaveSpace,
           UsernameValidator.shouldNotHaveSpecialCharacters],
           [
              usernameExistsValidator()
           ]), 
        password : new FormControl('',Validators.required)
    }
  )
 

 

   get username(){
     return this.form.get("username");
   }

    get loginform(){
           return this.form;
    }

  login(){

    console.log(this.form.value);

     // this.router.navigateByUrl("/dashboard?name=kiran");
  }

}
