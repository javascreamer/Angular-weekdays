import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UsernameValidator } from '../User.Validator';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  form = new FormGroup(
    {
        username: new FormControl('',[Validators.required, Validators.minLength(5), Validators.maxLength(10), UsernameValidator.shouldNotHaveSpace]), 
        password : new FormControl('',Validators.required)
    }
  )

  constructor(private router:Router){

  }

   get username(){
     return this.form.get("username");
   }

  login(){

    console.log(this.form.value);

     // this.router.navigateByUrl("/dashboard?name=kiran");
  }

}
