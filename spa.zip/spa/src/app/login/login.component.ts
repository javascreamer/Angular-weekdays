import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { existingUserNameValidator, UsernameValidator } from '../User.Validator';
import { UserService } from '../user.service';
import { UsernameValidatorService } from '../usernamevalidator.service';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,CommonModule],
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  form!: FormGroup;

  constructor(private usernameValidator: UsernameValidatorService, private userService:UserService) {}

  ngOnInit(): void {
    this.form = new FormGroup({
      username: new FormControl(
        '',
        [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(10),
          UsernameValidator.shouldNotHaveSpace,
          UsernameValidator.shouldNotHaveSpecialCharacters
        ],
        [existingUserNameValidator(this.userService)] // ✅ async validator
      ),
      password: new FormControl('', [Validators.required])
    });
  }

  get username() {
    return this.form.get('username') as FormControl;
  }

  login() {
    console.log(this.form.value);
  }

}


// Order:  All sync validations -> async validations