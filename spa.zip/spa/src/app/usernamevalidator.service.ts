import { Injectable } from '@angular/core';
import {
  AbstractControl,
  AsyncValidator,
  ValidationErrors
} from '@angular/forms';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class UsernameValidatorService implements AsyncValidator {
  private takenUsernames = ['admin', 'john', 'testuser'];

  validate(control: AbstractControl): Observable<ValidationErrors | null> {
    return of(this.takenUsernames.includes(control.value)).pipe(
      delay(500),
      map(isTaken => (isTaken ? { usernameTaken: true } : null))
    );
  }
}
