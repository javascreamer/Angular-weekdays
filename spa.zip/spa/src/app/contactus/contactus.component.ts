import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { existingUserNameValidator, UsernameValidator } from '../User.Validator';
import { UserService } from '../user.service';

@Component({
  selector: 'app-contactus',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './contactus.component.html',
  styleUrl: './contactus.component.css'
})
export class ContactusComponent {

  contactForm:any;

  constructor(private formBuilder:FormBuilder,private userService:UserService){

    this.contactForm = this.formBuilder.group({

        username: ['',[Validators.required,UsernameValidator.shouldNotHaveSpace],[existingUserNameValidator(this.userService)]],
        emailId:[''], 
        message:['']

    })

  }

  get username(){
    return this.contactForm.get("username");
  }

}



