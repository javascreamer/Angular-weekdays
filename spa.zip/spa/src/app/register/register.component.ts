import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  imports: [FormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  
   firstName:string = "";
   lastName:string = "";
   mobileNumber:string = "";
   password:string = "";
   emailId:string = "";

   constructor(private userService:UserService, private router:Router){

   }

   checkValue(x:any){
         console.log(x.value);
   }


   register(data:any){

    console.log(data.value);
    
    //  let user= {
    //   firstName:this.firstName,
    //   lastName:this.lastName,
    //   mobileNumber:this.mobileNumber,
    //   password:this.password,
    //   emailId:this.emailId

    //  }
    //  console.log(user);

     return;
  //    this.userService.registerUser(user).subscribe( (response:any) =>{
  //            console.log(response);

  //            if(response.result._id){
  //                 this.router.navigateByUrl("/dashboard");
  //            }

  //    },
    
  //    (error) =>{
  //              console.log(error);
  //    });
   }
}
