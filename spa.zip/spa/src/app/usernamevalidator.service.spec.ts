import { TestBed } from '@angular/core/testing';

import { UsernamevalidatorService } from './usernamevalidator.service';

describe('UsernamevalidatorService', () => {
  let service: UsernamevalidatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UsernamevalidatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
