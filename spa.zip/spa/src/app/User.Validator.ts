import { AbstractControl, AsyncValidatorFn, ValidationErrors } from "@angular/forms";
import { UserService } from "./user.service";

import { Observable, of } from 'rxjs';
import { map, delay } from 'rxjs/operators';

export class UsernameValidator{


    static shouldNotHaveSpace(control:AbstractControl):ValidationErrors | null{

         if((control.value as string).includes(" ")){
            return {
                shouldNotHaveSpace: true
            }
         }
         else{
            return {
                shouldNotHaveSpace: false
            }
         }

    }
    static shouldNotHaveSpecialCharacters(control:AbstractControl):ValidationErrors | null{
        const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
          var result = specialChars.test(control.value as string); 
          if(result){
            return {
                shouldNotHaveSpecialCharacters: true
            }
          }
          else{
            return {
                shouldNotHaveSpecialCharacters: false
            }
          }
    }
    static isUsernameTaken(username: string): Observable<boolean> {
      let  usernames = ["kiran","rajesh","naveen","venkat"];

        const isTaken = usernames.includes(username);
        return of(isTaken).pipe(delay(1000)); // Simulate server delay
      }  
}
export function usernameExistsValidator(): AsyncValidatorFn {
    console.log("inside usernameExistsValidator");
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
        console.log("control.value:", control.value);
      return UsernameValidator.isUsernameTaken(control.value).pipe(
        map(isTaken => (isTaken ? { usernameTaken: true } : null))
      );
    };
}



 