import { AbstractControl, ValidationErrors } from "@angular/forms";

export class UsernameValidator{

    static shouldNotHaveSpace(control:AbstractControl):ValidationErrors | null{

         if((control.value as string).includes(" ")){
            return {
                shouldNotHaveSpace: true
            }
         }
         else{
            return {
                shouldNotHaveSpace: false
            }
         }

    }

}