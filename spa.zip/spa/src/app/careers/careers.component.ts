import { Component } from '@angular/core';

@Component({
  selector: 'app-careers',
  imports: [],
  templateUrl: './careers.component.html',
  styleUrl: './careers.component.css'
})
export class CareersComponent {

}
